import { Component, OnInit } from '@angular/core';
import { EmptyError } from 'rxjs';
import { Role } from 'src/app/common/enums/role';
import {IUser} from 'src/app/interface/user';
import * as data from 'src/json/employee.json';


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})

export class TableComponent implements OnInit {
  employeesjson=data;           //fetching data from json
  users: IUser<string,number>[]="data" as any;
  //  ad:Role.Admin;
  //  addd:Role.SuperAdmin;
  //  sub:Role.Subscriber;


  
  
  hideTable = false;
  id="";
  constructor()
   {
      console.log(this.employeesjson.employees);
   }

  ngOnInit(): void {
  }

//on the click of load data
  onClick(){
    this.hideTable = true;
    const loadbtn = document.getElementById("loadData") as HTMLElement; 
    loadbtn.innerHTML = "Refresh Data"; 
  //  this.employeesjson.employees.forEach(element => {
  //   if(element.role
      
  //   });
    
    }

//on the click of Edit button
    onEditClick(user: any){
    this.employeesjson.employees.forEach(element => {
        element.isEdit=false;
      });
      user.isEdit = true;
    }
//on the click of Save Button
    onSaveClick(id:any){

        for(let i = 0; i < this.employeesjson.employees.length; ++i)
          {
               if (this.employeesjson.employees[i].id === id) 
               {
                
                    
               }
         }
    }
        
      
       
    

//On the click of Cancel Button
    onCancel(user: any){
      user.isEdit = false;
    }

// On the Click of Delete button
    onDelete(id:any){
      let response: any = confirm("Are you sure you want to delete this permanently?");
      if (response)
       {
          for(let i = 0; i < this.employeesjson.employees.length; ++i)
          {
            if (this.employeesjson.employees[i].id === id) 
            {
            this.employeesjson.employees.splice(i,1);
            }
          }
       }
    }
}
