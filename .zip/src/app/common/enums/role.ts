export enum Role {
    SuperAdmin="0",
    Admin="1",
    Subscriber="2"
  }

   

   

  