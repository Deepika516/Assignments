// import { Pipe, PipeTransform } from '@angular/core';
// import { DatePipe } from '@angular/common'
// import { TableComponent } from '../Components/table/table.component';

// @Pipe({
//   name: 'dateformat'
// })
// export class DateformatPipe implements PipeTransform {

//   transform(value: unknown, ...args: unknown[]): unknown {
//     return null;
//   }
//   constructor(public datepipe: DatePipe){}

//   myFunction(){
//     this.date=new Date();
//     let latest_date =this.datepipe.transform(this.date, 'yyyy-MM-dd');
//    }
//   date(date: any, arg1: string) {
//     throw new Error('Method not implemented.');
//   }

// }
